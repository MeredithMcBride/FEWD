/*

The Bank of Programming needs you to create an account javascript object. It should have an owner, account number, balance, and date opened attributes. 
The Bank of Programming gives customers 100$ to start. 
Use a function to setup the account and ask the user to input the owner's name and account number. 


Show the account status by outputting the account information to the browser using console.log().

Bonus: 

Look up the Javascript new Date() class to assign the current date and time to the date opened attribute.

*/